document.addEventListener('alpine:init', () => {
    Alpine.data('userForm', () => ({
        user: {
            id: null,
            name: '',
            email: '',
            phone: '',
            company: '',
            is_active: true  
        },

        async loadUser(userId) {
            try {
                const response = await fetch(`http://localhost:8000/users/${userId}`);
                if (!response.ok) {
                    throw new Error(`Failed to fetch user data. Status: ${response.status}`);
                }

                const userData = await response.json();
             
                this.user = { 
                    ...userData, 
                    is_active: userData.is_active === 'true' ? true : false
                };  
            } catch (error) {
                console.error('Error loading user data:', error);
                alert('Failed to load user data. Please try again.');
            }
        },

        async updateUser() {
            
            this.user.is_active = this.user.is_active === 'true' || this.user.is_active === true;

            try {
                const response = await fetch(`http://localhost:8000/usersupdate/${this.user.id}`, {
                    method: 'PUT',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify(this.user), 
                });

                if (!response.ok) {
                    throw new Error(`Failed to update user. Status: ${response.status}`);
                }

                const updatedUser = await response.json();
                console.log('User updated:', updatedUser);
                
                alert('User updated successfully!');
                window.location.href = '/';  
            } catch (error) {
                console.error('Error updating user:', error);
                alert('Failed to update user. Please try again.');
            }
        }
    }));
});
