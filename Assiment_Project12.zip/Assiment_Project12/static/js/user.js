function users(){
   
    return{
        users : [],
        async getUsers() {
            try {
                debugger
                const response = await fetch(`http://localhost:8000/users`);
                if (!response.ok) {
                    throw new Error('Failed to fetch users');
                }
                this.users = await response.json();
            } catch (error) {
                console.error('Error fetching users:', error);
            }
        },

     
        async getDelete(userId) {
            try {
                const response = await fetch(`http://localhost:8000/users/${userId}`, { method: 'DELETE' });
        
                if (!response.ok) {
                    throw new Error(`Failed to delete user with ID ${userId}: ${response.statusText}`);
                }
                const user = await response.json(); 
        
                this.users = this.users.filter((us) => us.id !== userId);
                
                console.log('Deleted user data:', user);
                this.selectedUser = user;
            } catch (error) {
                console.error('Error deleting user data:', error);
            }
        },

        async init(){
            this.getUsers()
        }
    };
    
}