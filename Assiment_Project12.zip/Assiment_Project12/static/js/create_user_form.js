document.addEventListener('alpine:init', () => {
    Alpine.data('userForm', () => ({
        newUser: {
            name: '',
            email: '',
            phone: '',
            company: '',
            status: 'Active'
        },
        async getCreate() {
            try {
                const response = await fetch('http://localhost:8000/users', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify(this.newUser),
                });

                if (!response.ok) {
                    throw new Error(`Failed to create user. Status: ${response.status}`);
                }

                const createdUser = await response.json();
                console.log('User created:', createdUser);

                alert('User added successfully!');
                window.location.href = '/';  

                // Reset form fields
                this.newUser = {
                    name: '',
                    email: '',
                    phone: '',
                    company: '',
                    status: 'Active',
                };
            } catch (error) {
                console.error('Error creating user:', error);
                alert('Failed to add user. Please try again.');
            }
        }
    }));
});
