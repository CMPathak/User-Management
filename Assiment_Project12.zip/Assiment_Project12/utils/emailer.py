from fastapi_mail import FastMail, MessageSchema, ConnectionConfig, MessageType
from .config import settings
 
email_conf = ConnectionConfig(
    MAIL_USERNAME = settings.MAIL_USERNAME,
    MAIL_PASSWORD = settings.MAIL_PASSWORD,
    MAIL_FROM = settings.MAIL_FROM,
    MAIL_STARTTLS = True,
    MAIL_SSL_TLS=False,
    # TEMPLATE_FOLDER=settings.MAIL_TEMPLATE_FOLDER
)
 
async def send_email(email_ids : list, body : str, subject : str):
    try:
        message = MessageSchema(
            subject = subject,
            recipients = [email_ids],
            body = body,
            subtype=MessageType.html
            )
        fm = FastMail(email_conf)
        res = await fm.send_message(message)
        return res
    except Exception as e:
        print(e)
        return e