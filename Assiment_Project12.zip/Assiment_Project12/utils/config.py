from pydantic.v1 import BaseSettings
 
 
class Settings(BaseSettings):
    DATABASE_URL : str
    MAIL_USERNAME : str
    MAIL_PASSWORD :str
    MAIL_FROM : str
    USER_PAGE_LIMIT : int 
    class Config:env_file = ".env"
    
settings = Settings()  